import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'aFilePreviewer',
  templateUrl: './a-file-previewer.component.html',
  styleUrls: ['./a-file-previewer.component.scss']
})
export class AFilePreviewerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
